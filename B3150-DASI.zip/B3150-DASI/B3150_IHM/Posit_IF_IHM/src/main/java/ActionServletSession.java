/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import posit_if.DAO.JPAUtil;
import posit_if.OM.Client;
import posit_if.Service.Service;
/**
 *
 * @author woccelli
 */
@WebServlet(urlPatterns = {"/ActionServlet"})
public class ActionServletSession extends HttpServlet {

    
   
    @Override
    public void init()
            throws ServletException {
        super.init(); //To change body of generated methods, choose Tools | Templates.
        JPAUtil.init();
    }

    @Override
    public void destroy() {
        super.destroy(); //To change body of generated methods, choose Tools | Templates.
        JPAUtil.destroy();
    }
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        
        if("connecter".equals(action)){
            String user = request.getParameter("login");
            try(PrintWriter out = response.getWriter()){
                Client c = Service.authentificationClient(user);
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                JsonObject container = new JsonObject();
                             
                if( c != null){
                    System.out.println(user);
                    session.setAttribute("user",user);
                    JsonObject jsonClient = new JsonObject();
                    jsonClient.addProperty("status", true);
                    jsonClient.addProperty("id",c.getId());
                    jsonClient.addProperty("adresse",c.getAddresse());
                    jsonClient.addProperty("civilite",c.getCivilite());
                    jsonClient.addProperty("mail",c.getMail());
                    jsonClient.addProperty("nom",c.getNom());
                    jsonClient.addProperty("prenom",c.getPrenom());
                    jsonClient.addProperty("signe_ch",c.getSigne_ch());
                    jsonClient.addProperty("signe_z",c.getSigne_z());
                    jsonClient.addProperty("tel",c.getTel());
                    jsonClient.addProperty("couleur",c.getCouleur());
                    jsonClient.addProperty("totem",c.getTotem());
                    container.add("client",jsonClient);
                    System.out.println(jsonClient);
                }
                else{
                    JsonObject jsonClient = new JsonObject();
                    jsonClient.addProperty("status", false);
                    container.add("client",jsonClient);
                }
                out.println(gson.toJson(container));
            }
        }
        else{
            try (PrintWriter out = response.getWriter()) {
                /* TODO output your page here. You may use following sample code. */
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet ActionServletSession</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Servlet ActionServletSession at " + request.getContextPath() + "</h1>");
                out.println("</body>");
                out.println("</html>");
            }
        }
        
    }

   /* @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       processRequest(req,resp);
    }*/

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
